# Security Policy

+ if have any Vulnerability finded contact: Author(KanzuWakazaki.Main@proton.me) or (Facebook.com/Lazic.Kanzu). Thanks!

## Supported Versions

Use this section to tell people about which versions of your project are
currently being supported with security updates.

| Version | Supported          |
| ------- | ------------------ |
| StableVersion | :white_check_mark: |
| AutoUpdate | :white_check_mark:|
| Modified | :x:

## Reporting a Vulnerability

Contact Author or create pull!
